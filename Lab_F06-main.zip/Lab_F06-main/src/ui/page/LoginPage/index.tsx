import NavList from "../../component/NavList";

export default function LoginPage() {
    return(
        <div className="shopping-cart-container">
            <NavList/>
            <h1>Login Page!</h1>
        </div>
    )
}